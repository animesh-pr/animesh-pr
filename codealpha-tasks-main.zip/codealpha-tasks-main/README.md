# codealpha-tasks
Task 1).Hangman Game  -Design a text-based Hangman game. The program selects a random
word, and the player guesses one letter at a time to uncover the word.
You can set a limit on the number of incorrect guesses allowed.

Task 2).Stock PortfolioTracker  -Create a stock portfolio tracking tool that allows users to add,
remove, and track the performance of their stock investments.
Utilize financial APIs for real-time stock data.

Task 3).BasicChatbot  -Create a text-based chatbot that can have conversations with users.
You can use natural language processing libraries like NLTK or spaCy
to make your chatbot more conversational.
